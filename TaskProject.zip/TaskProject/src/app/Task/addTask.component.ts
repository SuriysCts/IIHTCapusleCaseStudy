import { Component, OnInit, ViewChild} from '@angular/core';
import {NgModule, Input}  from '@angular/core';
import {Router}  from '@angular/router';
import {TaskService} from './service/Task.service';
import {Taskdetails} from './Model/Taskdetails';

@Component({
    selector:'TaskAdd',
    templateUrl : './View/addTask.component.html',
    providers:[TaskService]
})


export class AddTaskComponent implements OnInit{

    Taskdetails : Taskdetails;
    constructor(private taskService:TaskService){}
    ngOnInit(){
        this.Taskdetails = new Taskdetails();
    }

    AddTask(){
        this.taskService.addTaskDetails(this.Taskdetails).subscribe(
            res=> {
              
            }
        )
    }
}