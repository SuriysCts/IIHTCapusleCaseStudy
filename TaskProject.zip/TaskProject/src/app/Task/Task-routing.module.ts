import {NgModule} from '@angular/core';
import {Routes,RouterModule} from '@angular/router';
import { AddTaskComponent } from './addTask.component';
import { ViewTaskComponent } from './viewTask.component';
import { HomeComponent } from './home.component';

const routes: Routes=[
    {path:'addTask', component:AddTaskComponent,
     data:{RouterName:'home'}},
    {path:'viewTask', component:ViewTaskComponent,  data:{RouterName:'home'}},
  
];

@NgModule(
    {
        imports:[
            RouterModule.forChild(routes)
        ],
        exports:[
            RouterModule
        ]

    })

    export class HomeRoutingModule{}