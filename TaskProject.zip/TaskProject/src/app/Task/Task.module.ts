import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes,RouterModule } from '@angular/router';
import { AddTaskComponent } from './addTask.component';
import { ViewTaskComponent } from './viewTask.component';
import { HomeComponent } from './home.component';
import { HomeRoutingModule } from './Task-routing.module';

@NgModule({
  declarations: [
    AddTaskComponent,
    ViewTaskComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    HomeRoutingModule
  ],
  providers: []
})
export class TaskModule { }
