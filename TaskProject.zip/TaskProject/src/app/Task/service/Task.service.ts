import {Injectable} from '@angular/core';
import {Http, Headers, Response, RequestOptions} from '@angular/http';
import { Observable, observable } from 'rxjs';
import 'rxjs/Rx';
import {map, catchError} from 'rxjs/operators';
import {Taskdetails} from '../Model/TaskDetails';
@Injectable()
export class TaskService{
    constructor(private http: Http){}

    private viewTaskURL = "http://localhost:49598/api/Task/ViewTask";
    private addTaskURL = "http://localhost:49598/api/Task/AddTask";
    private updateTaskURL = "http://localhost:49598/api/Task/UpdateTask";
    getTaskDetails(taskId:any): Observable<Taskdetails[]>{
        return this.http.get(this.viewTaskURL+ "?taskId=" + taskId).pipe(
            map(res=> res.json()),
            catchError(err=>Observable.throw(err))
        );
    
    }
    addTaskDetails(Taskdetails:Taskdetails): Observable<Taskdetails[]>{
        return this.http.post(this.addTaskURL, Taskdetails).pipe(
            map(res=> res.json()),
            catchError(err=>Observable.throw(err))
        );
    
    }
    updateTaskDetails(taskId:any,  taskdetails:Taskdetails): Observable<Taskdetails[]>{
        return this.http.post(this.updateTaskURL+ "?id=" + taskId, taskdetails).pipe(
            map(res=> res.json()),
            catchError(err=>Observable.throw(err))
        );
    
    }
}