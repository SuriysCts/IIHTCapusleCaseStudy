import { Component, OnInit, ViewChild} from '@angular/core';
import {NgModule, Input}  from '@angular/core';
import {Router}  from '@angular/router';
import {TaskService} from './service/Task.service';
import {Taskdetails} from './Model/Taskdetails';

@Component({
    selector:'TaskView',
    templateUrl : './View/viewTask.component.html',
    providers:[TaskService]
})


export class ViewTaskComponent implements OnInit{

    taskDetailsList : Taskdetails[];
    columns : string[];
    constructor(private taskService:TaskService){}
    ngOnInit(){
        this.taskDetailsList = [];
        this.columns =['TaskId','TaskName','ParentName', 'Priority','StartDate'
        ,'EndDate' ]
    }
    GetTaskDetailsList(){
        this.taskService.getTaskDetails(0).subscribe(
            res=> {
                this.taskDetailsList = res;
            }
        )
    }
}