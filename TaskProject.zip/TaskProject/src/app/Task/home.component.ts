import { Component, OnInit, ViewChild} from '@angular/core';
import {NgModule, Input}  from '@angular/core';
import {Router}  from '@angular/router';

@Component({
    selector:'home',
    templateUrl : './View/home.component.html'
})


export class HomeComponent implements OnInit{

    ngOnInit(){
        
    }
}