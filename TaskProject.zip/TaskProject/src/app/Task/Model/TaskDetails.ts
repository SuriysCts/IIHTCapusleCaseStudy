export class Taskdetails{
    TaskId: number;
    TaskName: string;
    ParentName: string;
    StartDate: Date;
    EndDate: Date;
    Priority: number;
    Error: string;
    EndTask: boolean;
}