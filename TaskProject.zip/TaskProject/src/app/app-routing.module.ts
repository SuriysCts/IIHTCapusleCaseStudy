import {NgModule} from '@angular/core';
import {Routes, RouterModule, ActivatedRouteSnapshot} from '@angular/router';

import {HomeComponent} from './Task/home.component'
import {AddTaskComponent} from './Task/addTask.component'
import {ViewTaskComponent} from './Task/viewTask.component'

export const routes:Routes = [
    
    {path:'home', component:HomeComponent},
    {path:'addTask', component:AddTaskComponent},
    {path:'viewTask', component:ViewTaskComponent}
];

@NgModule(
    {
        imports:[RouterModule.forRoot(routes)],
        exports:[RouterModule]
    }
)export class AppRoutingModule{}