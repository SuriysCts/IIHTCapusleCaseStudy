﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CapsuleAPI.Models;

namespace CapsuleAPI.Controllers
{
    [RoutePrefix("api/Task")]
    public class TaskController : ApiController
    {

        [HttpGet]
        [Route("ViewTask")]
        public List<TaskDetails> Get(int id)
        {
            List<TaskDetails> taskList = new List<TaskDetails>();
         
                using (CaspsuleTaskEntities capent = new CaspsuleTaskEntities())
                {
                if (id == 0)
                {
                    taskList = (from t in capent.Tasks
                                join p in capent.ParentTasks on t.Parent_ID equals p.Parent_ID
                                select new TaskDetails()
                                {
                                    TaskId = t.Task_ID,
                                    TaskName = t.Task1,
                                    ParentName = p.Parent_Task,
                                    StartDate = t.Start_Date,
                                    EndDate = t.End_Date,
                                    Priority = t.Priority
                                }
                               ).ToList();
                }
                else
                {
                    taskList = (from t in capent.Tasks
                                join p in capent.ParentTasks on t.Parent_ID equals p.Parent_ID
                                where t.Task_ID == id
                                select new TaskDetails()
                                {
                                    TaskId = t.Task_ID,
                                    TaskName = t.Task1,
                                    ParentName = p.Parent_Task,
                                    StartDate = t.Start_Date,
                                    EndDate = t.End_Date,
                                    Priority = t.Priority
                                }
                              ).ToList();
                }
            }

            return taskList;

        }

        [HttpPost]
        [Route("AddTask")]
        public void Post([FromBody]TaskDetails task)
        {
            using (CaspsuleTaskEntities capent = new CaspsuleTaskEntities())
            {
                capent.ParentTasks.Add(new ParentTask()
                {
                    Parent_Task = task.ParentName
                });
                capent.SaveChanges();
                var Parentid = capent.ParentTasks.Where(x => x.Parent_Task == task.ParentName).Select(x => x.Parent_ID).FirstOrDefault();
                capent.Tasks.Add(new Task()
                {
                    Parent_ID = Parentid,
                    Task1 = task.TaskName,
                    Start_Date = task.StartDate,
                    End_Date = task.EndDate,
                    Priority = task.Priority
                });
                capent.SaveChanges();
            }

        }

        [HttpPost]
        [Route("UpdateTask")]
        public TaskDetails Put(int id, [FromBody]TaskDetails task)
        {
            if (task.EndDate > DateTime.Now)
            {
                using (CaspsuleTaskEntities capent = new CaspsuleTaskEntities())
                {
                    capent.ParentTasks.Add(new ParentTask()
                    {
                        Parent_Task = task.ParentName
                    });
                    capent.SaveChanges();
                    var Parentid = capent.ParentTasks.Where(x => x.Parent_Task == task.ParentName).Select(x => x.Parent_ID).FirstOrDefault();
                    capent.Tasks.Add(new Task()
                    {
                        Parent_ID = Parentid,
                        Task1 = task.TaskName,
                        Start_Date = task.StartDate,
                        End_Date = task.EndDate,
                        Priority = task.Priority
                    });
                    capent.SaveChanges();
                }
            }
            else
                task.Error = "Task has been ended. Cannot be edited";

            if (task.EndTask)
            {
                using (CaspsuleTaskEntities capent = new CaspsuleTaskEntities())
                {
                    capent.ParentTasks.Add(new ParentTask()
                    {
                        Parent_Task = task.ParentName
                    });
                    capent.SaveChanges();
                    var Parentid = capent.ParentTasks.Where(x => x.Parent_Task == task.ParentName).Select(x => x.Parent_ID).FirstOrDefault();
                    capent.Tasks.Add(new Task()
                    {
                        Parent_ID = Parentid,
                        Task1 = task.TaskName,
                        Start_Date = task.StartDate,
                        End_Date = DateTime.Now,
                        Priority = task.Priority
                    });
                    capent.SaveChanges();
                }
            }

                return task;
        }

    }
}
