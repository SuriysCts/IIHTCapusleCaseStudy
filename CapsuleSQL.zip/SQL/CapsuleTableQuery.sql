Create Database CapsuleTask

create table ParentTask
(
Parent_ID int primary key identity(1,1),
Parent_Task varchar(100)
)

create table Task
(
Task_ID int primary key identity(1,1),
Parent_ID int foreign key references ParentTask(Parent_ID),
Task varchar(100),
Start_Date date,
End_Date date,
Priority int
)

insert into ParentTask values('Parent1')
insert into Task values(1,'Task1',GETDATE(),GETDATE(),5)